# Customer Behaviour Analysis

**Status:** Suggested portfolio project — not yet represented as completed work.

## Objective
Explore customer purchasing patterns and identify useful customer segments.

## Suggested analysis
- Repeat versus one-time customers
- Purchase frequency and recency
- Average basket value
- Product/category preferences
- Customer cohorts or retention indicators, if the dataset supports them

## Tools
Python, SQL and Tableau or Power BI.

## Deliverables
- Dataset source and data dictionary
- SQL queries and Python notebook
- Charts/dashboard
- Findings supported by actual data
- Recommendations and limitations

Avoid claiming churn prediction or causal conclusions unless the data and method support them.
