# Business Data Analysis

**Status:** Project listed on my resume. Add supporting files and evidence before presenting this as a detailed case study.

## Summary
Analyzed business datasets using Python, MySQL and Excel. Created interactive dashboards using Power BI and Tableau, and identified business insights through data visualization and KPI analysis.

## Tools
- Python
- MySQL
- Microsoft Excel
- Power BI
- Tableau

## Add your work here
- `data/` — dataset or a link to its source (respect licensing and privacy)
- `notebooks/` — Python analysis
- `sql/` — SQL queries
- `dashboard/` — dashboard screenshots or public links
- `images/` — charts and dashboard previews

## Case-study details to complete
1. Business problem and objective
2. Dataset source, size and fields
3. Data cleaning steps
4. SQL queries and Python methods
5. KPIs and dashboard screenshots
6. Findings supported by actual data
7. Recommendations and limitations

Do not add numerical results or business impact until they have been calculated and verified.
