# Sales Performance Dashboard

**Status:** Suggested portfolio project — not yet represented as completed work.

## Objective
Create a dashboard that helps a business monitor sales performance and identify trends.

## Suggested analysis
- Revenue and order trends over time
- Sales by product/category and region
- Average order value
- Top and low-performing products
- Month-over-month performance

## Tools
Excel and Power BI.

## Deliverables
- Dataset source and data dictionary
- Data cleaning notes
- KPI definitions
- Dashboard screenshot and `.pbix` file (if shareable)
- Three to five findings supported by the data
- Practical recommendations

Add findings only after completing the analysis.
